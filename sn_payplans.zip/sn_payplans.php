<?php
defined('_JEXEC') or die('Restricted access');

class plgPayplansSn_payplans extends XiPlugin
{
	public function onPayplansSystemStart() 
	{
		$appPath = dirname(__FILE__) .DS. 'snpayplans' .DS. 'app';
		PayplansHelperApp::addAppsPath($appPath);
	}

}