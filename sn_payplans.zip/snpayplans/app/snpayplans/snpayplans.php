<?php
defined('_JEXEC') or die('Restricted access');

jimport('sncore.include');

class PayplansAppSnpayplans extends PayplansAppPayment
{
	protected $_location = __FILE__;

	public function __construct($config = array())
	{
        SNGlobal::loadLanguage('plg_payplans_sn_payplans',JPATH_ADMINISTRATOR);
		return parent::__construct($config);
	}

    function isApplicable($refObject = null,$eventName='')
    {
        if($eventName == 'onPayplansSubscriptionBeforeSave')
        {
            return true;
        }
        return parent::isApplicable($refObject,$eventName);
    }

	public function onPayplansPaymentForm(PayplansPayment $payment, $data = null)
	{
        $invoice   = $payment->getInvoice(PAYPLANS_INSTANCE_REQUIRE);
        $recurring = $invoice->isRecurring();

        if($recurring)
        {
            $getApp = PayplansFactory::getApplication();
            $getApp->enqueueMessage(XiText::_("COM_PAYPLANS_PAYMENT_APP_SN_DOES_NOT_SUPPORT_RECURRING"),'error');
            return;
        }

        $orderId = $invoice->getId();
        $amount = $invoice->getSubtotal();
        $backUrl = JURI::root().'index.php?option=com_payplans&gateway=snpayplans&view=payment&task=complete&payment_key='.$payment->getKey();;

        $pin = $this->getAppParam('sn_pin');
        $currency = $this->getAppParam('sn_currency');
        $sendPayerInfo = $this->getAppParam('sn_send_payer_info');

        $amount = SNApi::modifyPrice($amount,$currency);

        $data = array(
            'pin'=> $pin,
            'price'=> $amount,
            'callback'=> $backUrl,
            'order_id'=> $orderId,
            'description'=> '',
            'mobile'=> '',
        );

        list($status,$msg,$resultData) = SNApi::request($data,$sendPayerInfo,'payplans');

        if($status == true)
        {
            $data['bank_callback_details'] = $resultData['bank_callback_details'];
            $data['au'] = $resultData['au'];

            SNApi::clearData();
            SNApi::setData($data);

            $html = '';

            $html = '<div class="sn-go-to-bank">'.JText::_('SN_CONNECTING_TO_PORTAL').'</div>';
            $html .= SNGlobal::postData($resultData['form_details']['action'],$resultData['form_details']['fields'],1000);
            $this->assign('html',$html);
            return $this->_render('request');
        }


        $html = $msg;
        $this->assign('html',$html);
        return $this->_render('request');
	}

	public function onPayplansPaymentAfter(PayplansPayment $payment, &$action, &$data, $controller)
	{
        if($action == 'cancel')
        {
            return true;
        }

        $invoice = $payment->getInvoice(PAYPLANS_INSTANCE_REQUIRE);
        $amount = $invoice->getTotal();
        $orderId = $invoice->getId();
        $au = SNGlobal::getVar('au','','none','request');
        $sessionData = SNApi::getData();

        if(!empty($orderId) && !empty($au) && !empty($sessionData) && $sessionData['order_id'] == $orderId)
        {
            $bankData = array();
            foreach (!empty($sessionData['bank_callback_details']['params']) ? $sessionData['bank_callback_details']['params'] : array() as $bankParam)
            {
                $bankData[$bankParam] = !empty($_REQUEST[$bankParam]) ? $_REQUEST[$bankParam] : '';
            }

            $data = array (
                'pin' => $sessionData['pin'],
                'price' => $sessionData['price'],
                'order_id' => $sessionData['order_id'],
                'au' => $au,
                'bank_return' => $bankData,
            );

            list($status,$msg,$resultData) = SNApi::verify($data,'payplans');

            if($status == true)
            {
                $bankAu = !empty($resultData['bank_au']) ? $resultData['bank_au'] : $au;

                $myData = [
                    'ref_number' => $bankAu,
                ];

                $msg = '<h5>'.JText::_('SN_PAID_TRANSACTION').'</h5>';
                $msg = str_replace('{REF}',$bankAu,$msg);

                $transaction = PayplansTransaction::getInstance();
                $transaction->set('user_id', $invoice->getBuyer())
                    ->set('invoice_id', $invoice->getId())
                    ->set('payment_id', $payment->getId())
                    ->set('amount', $amount)
                    ->set('gateway_txn_id',$bankAu)
                    ->set('gateway_subscr_id',$bankAu)
                    ->set('message', $msg)
                    ->set('params', PayplansHelperParam::arrayToIni($myData))
                    ->save();
            }
        }

        return parent::onPayplansPaymentAfter($payment, $action, $data, $controller);
	}
}
