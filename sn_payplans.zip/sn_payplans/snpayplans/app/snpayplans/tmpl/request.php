<?php
defined('_JEXEC') or die('Restricted access');
?>

<div class="sn-payplans">
    <h5><?php echo $html; ?></h5>
</div>